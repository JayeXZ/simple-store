<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('orders', function (Blueprint $table) {
        if (!Schema::hasColumn('orders', 'invoice_url')) {
            $table->string('invoice_url')->nullable()->after('status');
        }
    });
}
 
public function down(): void 
{ 
    Schema::table('orders', function (Blueprint $table) { 
        $table->dropColumn('invoice_url'); 
    }); 
} 
};
